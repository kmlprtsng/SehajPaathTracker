(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/jasonaibrahim_angular-moment/packages/jasonaibrahim_angu //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['jasonaibrahim:angular-moment'] = {};

})();

//# sourceMappingURL=jasonaibrahim_angular-moment.js.map
