(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['urigo:angular-blaze-template'] = {};

})();

//# sourceMappingURL=urigo_angular-blaze-template.js.map
