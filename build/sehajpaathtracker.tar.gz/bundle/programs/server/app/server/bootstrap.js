(function(){Meteor.startup(function () {
	// if (Paaths.find().count() === 0) {
	// 	var paaths = [
	// 		{
	// 			title: "Family Sehaj Paath"
	// 		},
	// 		{
	// 			title: "Friends Sehaj Paath"
	// 		},
	// 		{
	// 			title: "Birthday Sehaj Paath"
	// 		}
	// 	];

	// 	paaths.forEach(paath => {
	// 		Paaths.insert(paath)
	// 	});
	// }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9zZXJ2ZXIvYm9vdHN0cmFwLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE1BQU0sQ0FBQyxPQUFPLENBQUMsWUFBWTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBa0IxQixDQUFDLENBQUMiLCJmaWxlIjoiL3NlcnZlci9ib290c3RyYXAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJNZXRlb3Iuc3RhcnR1cChmdW5jdGlvbiAoKSB7XHJcblx0Ly8gaWYgKFBhYXRocy5maW5kKCkuY291bnQoKSA9PT0gMCkge1xyXG5cdC8vIFx0dmFyIHBhYXRocyA9IFtcclxuXHQvLyBcdFx0e1xyXG5cdC8vIFx0XHRcdHRpdGxlOiBcIkZhbWlseSBTZWhhaiBQYWF0aFwiXHJcblx0Ly8gXHRcdH0sXHJcblx0Ly8gXHRcdHtcclxuXHQvLyBcdFx0XHR0aXRsZTogXCJGcmllbmRzIFNlaGFqIFBhYXRoXCJcclxuXHQvLyBcdFx0fSxcclxuXHQvLyBcdFx0e1xyXG5cdC8vIFx0XHRcdHRpdGxlOiBcIkJpcnRoZGF5IFNlaGFqIFBhYXRoXCJcclxuXHQvLyBcdFx0fVxyXG5cdC8vIFx0XTtcclxuXHJcblx0Ly8gXHRwYWF0aHMuZm9yRWFjaChwYWF0aCA9PiB7XHJcblx0Ly8gXHRcdFBhYXRocy5pbnNlcnQocGFhdGgpXHJcblx0Ly8gXHR9KTtcclxuXHQvLyB9XHJcbn0pOyJdfQ==
}).call(this);

//# sourceMappingURL=bootstrap.js.map
